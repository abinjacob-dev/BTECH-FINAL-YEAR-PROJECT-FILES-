import React, { Suspense, lazy } from "react";
import ReactDOM from "react-dom/client"; // Update this import for React 18
import "bootstrap/dist/css/bootstrap.min.css"; // Bootstrap CSS

// Lazy load the App component
const App = lazy(() => import("./App"));

// Use createRoot instead of render (for React 18+)
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <Suspense fallback={<div>Loading...</div>}>
      <App />
    </Suspense>
  </React.StrictMode>
);
