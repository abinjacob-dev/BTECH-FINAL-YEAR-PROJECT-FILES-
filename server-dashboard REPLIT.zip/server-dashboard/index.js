const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const compression = require('compression'); // Import compression middleware
const { MongoClient } = require('mongodb');
require('dotenv').config();

// Create Express app
const app = express();
const port = process.env.PORT || 5000;

// Serve centered image at root
app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
      <head>
        <style>
          body {
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
          }
          img {
            max-width: 100%;
            height: auto;
          }
        </style>
      </head>
      <body>
        <img src="/image" alt="Generated Icon">
      </body>
    </html>
  `);
});

// Serve the actual image file
app.get('/image', (req, res) => {
  res.sendFile('generated-icon.png', { root: __dirname });
});

// Middleware
// app.use(cors({
//   origin: 'https://2798a61b-985f-4360-babf-6393411d495e-00-4k3vuqecbhyl.pike.replit.dev',  // Allow requests from React's port
//   methods: ['GET', 'POST'], // Optional: Specify allowed methods
//   credentials: true // Optional: if your API requires authentication cookies
// }));
app.use(cors({
  origin: (origin, callback) => {
    const allowedOrigins = [
      'https://2798a61b-985f-4360-babf-6393411d495e-00-4k3vuqecbhyl.pike.replit.dev', // Add your React app's URL here
      'https://another-allowed-origin.com', // Add other allowed origins if needed
    ];

    // If the origin is allowed, call the callback with the origin
    if (allowedOrigins.includes(origin) || !origin) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  methods: ['GET', 'POST'],
  credentials: true, // Optional: if your API requires cookies/authentication
}));

app.use(express.json());
app.use(compression({ level: 9 })); // Enable Gzip compression with maximum compression level

// MongoDB connection setup
const mongoURI = process.env.MONGO_URI;
const dbName = process.env.DB_NAME;
const collectionName = process.env.COLLECTION_NAME;

const connectMongoDB = async () => {
  const client = new MongoClient(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true });
  try {
    await client.connect();
    console.log("Connected to MongoDB");
    const db = client.db(dbName);
    return db.collection(collectionName);
  } catch (error) {
    console.error("Error connecting to MongoDB:", error);
    process.exit(1);
  }
};

// API endpoint to get sensor data
app.get('/api/data', async (req, res) => {
  try {
    const collection = await connectMongoDB();
    const data = await collection.find({}).sort({ timestamp: -1 }).toArray();
    res.json(data);
  } catch (err) {
    console.error("Error fetching data:", err);
    res.status(500).json({ message: "Error fetching data", error: err });
  }
});

// Start server
app.listen(port, '0.0.0.0', () => {
  console.log(`Server running on port ${port}`);
});
